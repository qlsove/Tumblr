<?php defined('SYSPATH') or die('No direct script access.');

class Minion_CLI extends Kohana_Minion_CLI {}