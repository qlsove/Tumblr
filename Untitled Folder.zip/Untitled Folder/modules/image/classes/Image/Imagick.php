<?php defined('SYSPATH') OR die('No direct script access.');

class Image_Imagick extends Kohana_Image_Imagick {}