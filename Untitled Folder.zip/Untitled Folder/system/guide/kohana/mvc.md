<http://kohanaframework.org/guide/about.mvc>

Discuss the MVC pattern, as it pertains to Kohana.  Perhaps have an image, etc.