<?php defined('SYSPATH') OR die('No direct script access.');

class Request_Exception extends Kohana_Request_Exception {}
