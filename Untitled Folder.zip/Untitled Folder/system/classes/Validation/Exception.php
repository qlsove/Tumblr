<?php defined('SYSPATH') OR die('No direct script access.');

class Validation_Exception extends Kohana_Validation_Exception {}
