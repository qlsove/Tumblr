<?php defined('SYSPATH') OR die('No direct script access.');

class HTML extends Kohana_HTML {}
