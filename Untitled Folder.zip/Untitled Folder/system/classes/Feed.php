<?php defined('SYSPATH') OR die('No direct script access.');

class Feed extends Kohana_Feed {}
