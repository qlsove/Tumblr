<?php defined('SYSPATH') OR die('No direct script access.');

return array(

	'email' => array(
		'custom' => 'very nice email address you have there',
	),

);
