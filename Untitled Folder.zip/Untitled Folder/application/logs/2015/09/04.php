<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2015-09-04 01:04:11 --- EMERGENCY: ErrorException [ 1 ]: Call to undefined function mysql_connect() ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 59 ] in file:line
2015-09-04 01:04:11 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-09-04 01:08:03 --- EMERGENCY: ErrorException [ 1 ]: Call to undefined function mysql_connect() ~ MODPATH/database/classes/Kohana/Database/MySQL.php [ 59 ] in file:line
2015-09-04 01:08:03 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-09-04 01:18:50 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: NaN ~ APPPATH/classes/Controller/Ajax.php [ 63 ] in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 01:18:50 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/html/a...', 63, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 01:59:18 --- EMERGENCY: ErrorException [ 1 ]: Call to undefined function imagecreatefromgif() ~ APPPATH/classes/Cropper.php [ 27 ] in file:line
2015-09-04 01:59:18 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-09-04 01:59:35 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: NaN ~ APPPATH/classes/Controller/Ajax.php [ 63 ] in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 01:59:35 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/html/a...', 63, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 01:59:49 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: NaN ~ APPPATH/classes/Controller/Ajax.php [ 63 ] in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 01:59:49 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/html/a...', 63, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 01:59:50 --- EMERGENCY: ErrorException [ 1 ]: Call to undefined function imagecreatefromgif() ~ APPPATH/classes/Cropper.php [ 27 ] in file:line
2015-09-04 01:59:50 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-09-04 02:05:43 --- EMERGENCY: ErrorException [ 1 ]: Call to undefined function imagecreatefromgif() ~ APPPATH/classes/Cropper.php [ 27 ] in file:line
2015-09-04 02:05:43 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-09-04 02:05:45 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: NaN ~ APPPATH/classes/Controller/Ajax.php [ 63 ] in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 02:05:45 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/html/a...', 63, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 02:20:30 --- EMERGENCY: ErrorException [ 1 ]: Call to undefined function imagecreatefromgif() ~ APPPATH/classes/Cropper.php [ 27 ] in file:line
2015-09-04 02:20:30 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-09-04 02:20:33 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: NaN ~ APPPATH/classes/Controller/Ajax.php [ 63 ] in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 02:20:33 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/html/a...', 63, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 02:26:40 --- EMERGENCY: ErrorException [ 1 ]: Cannot use object of type Cropper as array ~ APPPATH/classes/Controller/Ajax.php [ 32 ] in file:line
2015-09-04 02:26:40 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2015-09-04 02:28:36 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/Controller/Ajax.php [ 32 ] in /var/www/html/application/classes/Controller/Ajax.php:32
2015-09-04 02:28:36 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(32): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/html/a...', 32, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_crop()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:32
2015-09-04 02:28:39 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: NaN ~ APPPATH/classes/Controller/Ajax.php [ 63 ] in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 02:28:39 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/html/a...', 63, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 02:32:58 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: NaN ~ APPPATH/classes/Controller/Ajax.php [ 63 ] in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 02:32:58 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/html/a...', 63, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 22:47:30 --- EMERGENCY: ErrorException [ 2 ]: chmod(): Operation not permitted ~ APPPATH/classes/Cropper.php [ 102 ] in file:line
2015-09-04 22:47:30 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'chmod(): Operat...', '/var/www/html/a...', 102, Array)
#1 /var/www/html/application/classes/Cropper.php(102): chmod('assets/images/1...', 511)
#2 /var/www/html/application/classes/Controller/Ajax.php(28): Cropper->create()
#3 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_crop()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#6 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/html/index.php(57): Kohana_Request->execute()
#9 {main} in file:line
2015-09-04 22:47:49 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: NaN ~ APPPATH/classes/Controller/Ajax.php [ 63 ] in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 22:47:49 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/html/a...', 63, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 22:48:02 --- EMERGENCY: ErrorException [ 2 ]: chmod(): Operation not permitted ~ APPPATH/classes/Cropper.php [ 102 ] in file:line
2015-09-04 22:48:02 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'chmod(): Operat...', '/var/www/html/a...', 102, Array)
#1 /var/www/html/application/classes/Cropper.php(102): chmod('assets/images/1...', 511)
#2 /var/www/html/application/classes/Controller/Ajax.php(28): Cropper->create()
#3 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_crop()
#4 [internal function]: Kohana_Controller->execute()
#5 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#6 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/html/index.php(57): Kohana_Request->execute()
#9 {main} in file:line
2015-09-04 22:49:00 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: NaN ~ APPPATH/classes/Controller/Ajax.php [ 63 ] in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-04 22:49:00 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/html/a...', 63, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:63