<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2015-09-07 20:41:29 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: NaN ~ APPPATH/classes/Controller/Ajax.php [ 63 ] in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-07 20:41:29 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/html/a...', 63, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-07 21:18:06 --- EMERGENCY: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/Controller/Ajax.php [ 63 ] in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-07 21:18:06 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(63): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/html/a...', 63, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-07 21:19:25 --- EMERGENCY: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/Controller/Ajax.php [ 63 ] in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-07 21:19:25 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(63): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/html/a...', 63, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:63
2015-09-07 21:43:47 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: items ~ APPPATH/classes/Controller/Ajax.php [ 49 ] in /var/www/html/application/classes/Controller/Ajax.php:49
2015-09-07 21:43:47 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(49): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/html/a...', 49, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:49
2015-09-07 21:46:11 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: items ~ APPPATH/classes/Controller/Ajax.php [ 49 ] in /var/www/html/application/classes/Controller/Ajax.php:49
2015-09-07 21:46:11 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(49): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/html/a...', 49, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:49
2015-09-07 21:48:34 --- EMERGENCY: ErrorException [ 8 ]: Undefined index: items ~ APPPATH/classes/Controller/Ajax.php [ 50 ] in /var/www/html/application/classes/Controller/Ajax.php:50
2015-09-07 21:48:34 --- DEBUG: #0 /var/www/html/application/classes/Controller/Ajax.php(50): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/html/a...', 50, Array)
#1 /var/www/html/system/classes/Kohana/Controller.php(84): Controller_Ajax->action_scroll()
#2 [internal function]: Kohana_Controller->execute()
#3 /var/www/html/system/classes/Kohana/Request/Client/Internal.php(97): ReflectionMethod->invoke(Object(Controller_Ajax))
#4 /var/www/html/system/classes/Kohana/Request/Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 /var/www/html/system/classes/Kohana/Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/html/index.php(57): Kohana_Request->execute()
#7 {main} in /var/www/html/application/classes/Controller/Ajax.php:50