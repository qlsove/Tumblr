<?php defined('SYSPATH') or die('No direct script access');
return array(
    'consumerKey'  => '9lwcLfP1HHbHF44L0bQwmRWhkQxkol05WgdW4wQVHUwJpZ9DBk',
    'consumerSecret'  => 'GcumlTFUghMpgOgUBwg0opqmOMUidPms5TaFNKw1Q0GEgEvdzh',
    'token'  => '1MEq6XGl919sjSomQ4isyeRqDyU9OkkmA7nlUA0tqCx0Xl9Osz',
    'tokenSecret'  => '5me8goTGgz4eefuaOhUL6i5cwb8vbQm6bJM2ReogfwFy6WdVCw',
    'blogName' => 'ghostphotographs',
);